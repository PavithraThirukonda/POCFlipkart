package flipkart_Test;


import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import flipkart_FunctionLibraries.Login;
import flipkart_FunctionLibraries.flipkart;

import java.util.LinkedHashMap;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import flipkart_Utils.ExcelRead;

public class DriverScript {
	
	public static ExcelRead excel=new ExcelRead();
	public static WebDriver driver = null;
	public static LinkedHashMap<String,String>fetchMapData=new LinkedHashMap();
	
	@BeforeSuite
	public void initialize() throws Exception {


		System.out.println("Browser Intialization");

	}


	@Test
	@Parameters({"datarow"})
	public void getTestCases(int datarow) throws Exception {


		try {
			Login.preRequesties(1);
			System.out.println("Login for the Datarow =" +datarow);
			Login.loginFlipkart(1);
			fetchMapData=flipkart.materialSelection(fetchMapData, datarow);
			Login.logoutFlipKart();
			
		} catch (Exception e) {
			throw new Exception(e);
		}
	}

	@AfterSuite
	public void quitBrowser() throws Exception {


		driver.quit();
		


	}

}
