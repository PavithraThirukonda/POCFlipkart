package flipkart_Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {

	File file= null;
	public static FileInputStream fi=null;
	public static XSSFWorkbook wb=null;
	public static XSSFSheet sh=null;
	public static XSSFRow row=null;
	public static String data=null;



	public String getCellData(int datarow,String sheetName,int index) throws IOException {
		try {
			String filename="Testdata.xlsx";
			file=new File(System.getProperty("user.dir")+"/src/test/java/Testdata/"+filename);
			fi=new FileInputStream(file);
			wb=new XSSFWorkbook(fi);
			sh=wb.getSheet(sheetName);
			data=sh.getRow(datarow).getCell(index).toString();

			
		} catch (Exception e) {

			e.printStackTrace();
		}		


		return data;

	}


}
