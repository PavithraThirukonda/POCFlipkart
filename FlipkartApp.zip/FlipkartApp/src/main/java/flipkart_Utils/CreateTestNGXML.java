package flipkart_Utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class CreateTestNGXML {

	
		public static void main(String[] args) throws IOException, ParserConfigurationException, TransformerException {
			
			try {
				ArrayList<Integer>values=new ArrayList();
				String filename="Testdata.xlsx";
				File file=new File(System.getProperty("user.dir")+"/src/test/java/Testdata/"+filename);
				//System.out.println("File="+file);
				FileInputStream fs=new FileInputStream(file);
				XSSFWorkbook wb=new XSSFWorkbook(fs);
				XSSFSheet sh=wb.getSheet("category");
				for(int i=1;i<=sh.getLastRowNum();i++) {
					String cellValue=sh.getRow(i).getCell(1).toString();
			
					if(cellValue !=null && cellValue.length()>0 && cellValue.equalsIgnoreCase("Y")) {
						values.add(sh.getRow(i).getRowNum());
					}
				}
				UpdateTestngfile.createTestNGfile(values);
				System.out.println(values);
				fs.close();
						
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
			
			
		}

	

}
