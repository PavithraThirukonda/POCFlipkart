package flipkart_Utils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.testng.TestNG;
import org.w3c.dom.Attr;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class UpdateTestngfile {

	public static void createTestNGfile(ArrayList<Integer>values) throws ParserConfigurationException, TransformerException {
		try {
			DocumentBuilderFactory docFactory=DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder=docFactory.newDocumentBuilder();
			
			//root elements
			Document doc=docBuilder.newDocument();
			Element rootElement=doc.createElement("suite");
			doc.appendChild(rootElement);
			
			//set name,thread-count add parallel attributes to suite element
			Attr name=doc.createAttribute("name");
			name.setValue("Automation Testing");
			rootElement.setAttributeNode(name);
			
			
			  Attr threadcount=doc.createAttribute("thread-count");
			  threadcount.setValue("1"); rootElement.setAttributeNode(threadcount);
			  
			  Attr parallel=doc.createAttribute("parallel"); parallel.setValue("tests");
			  rootElement.setAttributeNode(parallel);
			  
		    writeTestParameters(values, doc, rootElement);
			
			//write the content into XML file
			TransformerFactory transformerFactory=TransformerFactory.newInstance();
			Transformer transformer=transformerFactory.newTransformer();
			transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "http://testng.org/testng-1.0.dtd");
			
			DOMSource source=new DOMSource(doc);
			StreamResult result=new StreamResult(new File(System.getProperty("user.dir")+"\\testng.xml"));
			transformer.transform(source, result);
			
			System.out.println("File Saved!!");
			
			
			
		} catch (DOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	public static void writeTestParameters(ArrayList<Integer>values,Document doc,Element rootElement) {
		System.out.println("Values in Write Test Parameters" +values);
		
		for(int i=0;i<values.size();i++) {
			//test Parameter elements
			Element test=doc.createElement("test");
			rootElement.appendChild(test);
			
			//set attributes to test element
			Attr testname=doc.createAttribute("name");
			testname.setValue("TC" + values.get(i));
			test.setAttributeNode(testname);
			
			//set test parameters
			Element param1=doc.createElement("parameter");
			test.appendChild(param1);
			
			Attr param1name=doc.createAttribute("name");
			param1name.setValue("datarow");
			param1.setAttributeNode(param1name);
			
			Attr param1value=doc.createAttribute("value");
			param1value.setValue(String.valueOf(values.get(i)));
			param1.setAttributeNode(param1value);
			
			Element param2=doc.createElement("parameter");
			test.appendChild(param2);
			
			Attr param2name=doc.createAttribute("name");
			param2name.setValue("browser");
			param2.setAttributeNode(param2name);
			
			Attr param2value=doc.createAttribute("value");
			param2value.setValue("chrome");
			param2.setAttributeNode(param2value);
			
			Element classes=doc.createElement("classes");
			test.appendChild(classes);
			
			Element classs=doc.createElement("class");
			classes.appendChild(classs);
			
			Attr className=doc.createAttribute("name");
			className.setValue("flipkart_Test.DriverScript");
			classs.setAttributeNode(className);
			
			
			
			
		}
	}
	public static void invokeTestNGFiles() {
		try {
			TestNG testng=new TestNG();
			List<String>suites=new ArrayList();
			
			suites.add(System.getProperty("user.dir")+"/testng.xml");
			testng.setTestSuites(suites);
			testng.run();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
