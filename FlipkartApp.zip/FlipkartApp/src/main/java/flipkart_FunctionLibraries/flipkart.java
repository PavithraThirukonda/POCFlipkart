package flipkart_FunctionLibraries;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import flipkart_Test.DriverScript;


public class flipkart extends DriverScript{

	public static LinkedHashMap<String,String> materialSelection(LinkedHashMap<String,String>map,int datarow) throws Exception{
	
		String category=null;
		String excelData=null;
		String sort = null;
		String discountCol=null;
		
		try {
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			WebDriverWait wait=new WebDriverWait(driver,30);

			Thread.sleep(5000);


			List<WebElement>categorieslist=driver.findElements(By.xpath("//li[contains(@class,'Wbt')]"));
			for(int i=0;i<categorieslist.size();i++) {
				category= categorieslist.get(i).getText();
				excelData=excel.getCellData(datarow, "Category", 0);
				if(category.equalsIgnoreCase(excelData)) {
					categorieslist.get(i).click();
					excelData=excel.getCellData(datarow, "Category", 2);	
					WebElement subCategory=driver.findElement(By.xpath("//a[@title='"+excelData+"']"));
					subCategory.click();

					Thread.sleep(5000);

					List<WebElement>discount=driver.findElements(By.xpath("//div[contains(@title,'more')]"));
					for(int inc=0;inc<discount.size();inc++) {
						discountCol=discount.get(inc).getText();
						excelData=excel.getCellData(datarow, "Category", 4);
						if(discountCol.equalsIgnoreCase(excelData)) {
							discount.get(inc).click();
						}  
						discount=driver.findElements(By.xpath("//div[contains(@title,'more')]"));
					}
					
					Thread.sleep(5000);
					List<WebElement>priceRange=driver.findElements(By.xpath("//select[contains(@class,'fPjUPw')]"));
					List<String>ls=new ArrayList();
					String addList="";
					for(int inc=0;inc<priceRange.size();inc++) {
						
						 addList=priceRange.get(inc).getText();
						 ls.add(addList);
						
					}
				//	System.out.println("Checking...."+ls);
			
                 
					
					for(int k=0;k<priceRange.size();k++) {
						Select priceDropdown=new Select(priceRange.get(k));
						if(k==0) {
							excelData=excel.getCellData(datarow, "Category", 5);
							priceDropdown.selectByVisibleText(excelData);
						}
						else if(k==1) {
							priceDropdown.selectByVisibleText(excel.getCellData(datarow, "Category", 6));	
						}
						priceRange=driver.findElements(By.xpath("//select[@class='fPjUPw']"));
					}

					Thread.sleep(5000);

					List<WebElement>sortBy=driver.findElements(By.xpath("//div[contains(@class,'xHtJz')]"));
					for(int inc=0;inc<sortBy.size();inc++) {
						sort=sortBy.get(inc).getText();
						excelData=excel.getCellData(datarow, "Category", 3);


						if(sort.equalsIgnoreCase(excelData)) {
							sortBy.get(inc).click();
						}
						sortBy=driver.findElements(By.xpath("//div[contains(@class,'xHtJz')]"));
					}
					Thread.sleep(3000);

					driver.findElement(By.xpath("//img[contains(@class,'ogXc')]")).click();
					
                    String parentWindow=driver.getWindowHandle();
					Set<String>allWindows=driver.getWindowHandles();
					List<String>windowsList=new ArrayList();
					windowsList.addAll(allWindows);
					driver.switchTo().window(windowsList.get(1));
					
					
					WebElement itemType=driver.findElement(By.xpath("//span[contains(@class,'4LW6')]"));
					map.put("ItemType", itemType.getText());
					WebElement itemName=driver.findElement(By.xpath("//span[contains(@class,'5KyD6')]"));
					map.put("ItemName", itemName.getText());
					WebElement itemPrice=driver.findElement(By.xpath("//div[contains(@class,'_1vC4OE _3qQ9m1')]"));
					map.put("ItemPrice", itemPrice.getText());
					
					driver.switchTo().window(windowsList.get(1)).close();
					driver.switchTo().window(parentWindow);

					categorieslist=driver.findElements(By.xpath("//li[contains(@class,'Wbt')]"));

				}

			}
			System.out.println("Hashmap Values ="+map);

		} catch (Exception e) {
			System.out.println("Material Selection is failed"+e.getMessage());
			throw new Exception(e);


		}
		return map;
		

	}

}